package com.mra.rentcar.presenter.view.adapter.holder

import androidx.recyclerview.widget.RecyclerView.ViewHolder
import com.mra.testrantecarapp.databinding.CarsRecyclerViewRowBinding

class CarHolder(val binding: CarsRecyclerViewRowBinding): ViewHolder(binding.root) {
}