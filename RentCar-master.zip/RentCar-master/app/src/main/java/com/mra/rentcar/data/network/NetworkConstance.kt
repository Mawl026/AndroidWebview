package com.mra.rentcar.data.network

//const val BASE_URL = "https://www.mo-salim.com/api/"
const val BASE_URL = "https://www.mo-salim.com/sysproject/api/"
const val USER_LOGIN = "login"
const val CARS_LIST = "cars"
const val BOOKING_CAR = "booking"
