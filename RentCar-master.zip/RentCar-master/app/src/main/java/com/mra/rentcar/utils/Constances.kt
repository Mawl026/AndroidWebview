package com.mra.rentcar.utils

const val CAR_DATA = "CAR_DATA"
const val SHOW_LOGOUT = "SHOW_LOGOUT"
const val SELECTED_TIME = "SELECTED_TIME"